package br.unibh.escola.entidades;

import java.util.Date;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;


@Entity
@Table(name = "TB_SALA")
@NamedQueries({ @NamedQuery(name = "Sala.findByCapacidade", query = "select a from Sala a where a.capacidade >= :capacidade") })
public class Sala {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;

	@NotNull
	@NotBlank
	@Column(nullable=false)
	@Size(max = 10)
	private String codigo;

	@NotNull
	@Column(nullable=false)
	private int capacidade;

	private boolean possuiQuadroBranco;

	private boolean possuiDataShow;

	private boolean possuiComputador;

	@Size(max = 255)
	private String observacao;

	private int status;

	@Temporal(TemporalType.DATE)
	private Date dataTerminoManutencao;
	
	private String possui;
	private int dia;
	private int mes;
	private int ano;

	public Sala() {
	}

	public Sala(Long id, String codigo, int capacidade,
			boolean possuiQuadroBranco, boolean possuiDataShow,
			boolean possuiComputador, String observacao, int status,
			Date dataTerminoManutencao) {
		super();
		this.id = id;
		this.codigo = codigo;
		this.capacidade = capacidade;
		this.possuiQuadroBranco = possuiQuadroBranco;
		this.possuiDataShow = possuiDataShow;
		this.possuiComputador = possuiComputador;
		this.observacao = observacao;
		this.status = status;
		this.dataTerminoManutencao = dataTerminoManutencao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public int getCapacidade() {
		return capacidade;
	}

	public void setCapacidade(int capacidade) {
		this.capacidade = capacidade;
	}

	public boolean isPossuiQuadroBranco() {
		return possuiQuadroBranco;
	}
	
	public void setPossuiQuadroBranco(boolean possuiQuadroBranco) {
		this.possuiQuadroBranco = possuiQuadroBranco;
	}

	public String quadroToString(boolean possuiQuadroBranco) {
		if (isPossuiQuadroBranco()){
			possui = "sim";
		} else {
			possui = "nao";
		}
		return possui;
	}
	
	public boolean isPossuiDataShow() {
		return possuiDataShow;
	}

	public void setPossuiDataShow(boolean possuiDataShow) {
		this.possuiDataShow = possuiDataShow;
	}

	public String dataToString(boolean possuiDataShow) {
		if (isPossuiDataShow()){
			possui = "sim";
		} else {
			possui = "nao";
		}
		return possui;
	}
	
	public boolean isPossuiComputador() {
		return possuiComputador;
	}

	public void setPossuiComputador(boolean possuiComputador) {
		this.possuiComputador = possuiComputador;
	}

	public String pcToString(boolean possuiComputador) {
		if (isPossuiComputador()){
			possui = "sim";
		} else {
			possui = "nao";
		}
		return possui;
	}
	
	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String statusToString(int status) {
		if (getStatus() == 1){
			possui = "Ativo";
		} else if (getStatus() == 2){
			possui = "Em Manutencao";
		} else {
			possui = "Desativado";
		}
		return possui;
	}
	
	public Date getDataTerminoManutencao() {
		return dataTerminoManutencao;
	}

	public void setDataTerminoManutencao(Date dataTerminoManutencao) {
		this.dataTerminoManutencao = dataTerminoManutencao;
	}

	@SuppressWarnings("deprecation")
	public String terminoToString(Date dataTerminoManutencao) {
		if (getDataTerminoManutencao() == null){
			return null;
		}
		dia = getDataTerminoManutencao().getDate();
		mes = getDataTerminoManutencao().getMonth();
		ano = getDataTerminoManutencao().getYear() + 1900;
		return dia + "/" + mes + "/" + ano;
	}	
}
