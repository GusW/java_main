-- You can use this file to load seed data into the database using SQL statements
insert into Member (id, name, email, phone_number) values (0, 'John Smith', 'john.smith@mailinator.com', '2125551212'); 
insert into TB_PESSOA values (01,"10299955522","indiana jones")
insert into TB_PESSOA values (02,"10299955533","reitor")
insert into TB_PESSOA values (03,"10299955544","cain")


insert into TB_ALUNO values ("1991-07-24", 21, 01)
insert into TB_ALUNO values ("1992-07-24", 22, 02)
insert into TB_ALUNO values ("1993-07-24", 23, 03)

insert into TB_PROFESSOR values(1550, 01)
insert into TB_PROFESSOR values(2650, 02)
insert into TB_PROFESSOR values(4750, 03)